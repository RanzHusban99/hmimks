<?php
include '../db.php'; // Pastikan Anda menghubungkan file db.php dengan benar

// Mengambil data dari tabel surat_keluar
$result = mysqli_query($conn, "SELECT * FROM surat_keluar");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Surat Keluar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link rel="icon" href="../storage/situs/HMI (Himpunan Mahasiswa Islam).png" type="image/png" /> <!-- Menambahkan logo situs -->
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Daftar Surat Keluar</h2>
        
        <!-- Tombol Tambah Data -->
        <a href="tambah_surat_keluar.php" class="btn btn-primary mb-4">Tambah Surat Keluar</a>
        <a href="index.php" class="btn btn-secondary mb-4">Beranda</a>
        
        <!-- Tabel Surat Keluar -->
        <div class="table-responsive">
            <table id="suratKeluarTable" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>No Surat</th>
                        <th>Jenis Surat</th>
                        <th>Tanggal</th>
                        <th>Pengirim</th>
                        <th>Penerima</th>
                        <th>Perihal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['no_surat']; ?></td>
                            <td><?php echo $row['jenis_surat']; ?></td>
                            <td><?php echo $row['tanggal']; ?></td>
                            <td><?php echo $row['pengirim']; ?></td>
                            <td><?php echo $row['penerima']; ?></td>
                            <td><?php echo $row['perihal']; ?></td>
                            <td>
                                <a href="ubah_surat_keluar.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="hapus_surat_keluar.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus surat ini?');">Hapus</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <?php mysqli_close($conn); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#suratKeluarTable').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/Indonesian.json" // Jika Anda ingin menggunakan bahasa Indonesia
                }
            });
        });
    </script>
</body>
</html>
