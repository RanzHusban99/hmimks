<?php
include '../db.php'; // Menghubungkan ke database

// Menangani aksi tambah program kerja
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $status = $_POST['status'];

    // Menyimpan data ke database
    $sql = "INSERT INTO program_kerja (name, status) VALUES ('$name', '$status')";
    if ($conn->query($sql) === TRUE) {
        header("Location: program_kerja.php"); // Redirect setelah berhasil
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Tambah Program Kerja</title>
    <link href="css/styles.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="icon" href="../storage/situs/HMI (Himpunan Mahasiswa Islam).png" type="image/png" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Tambah Program Kerja</h1>
        <form method="POST" class="mt-4">
            <div class="mb-3">
                <label for="name" class="form-label">Nama Program Kerja</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Status</label>
                <div>
                    <input type="radio" id="terlaksana" name="status" value="terlaksana" required>
                    <label for="terlaksana">Terlaksana</label>
                
                    <input type="radio" id="belum_terlaksana" name="status" value="belum terlaksana" required>
                    <label for="belum_terlaksana">Belum Terlaksana</label>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="program_kerja.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
