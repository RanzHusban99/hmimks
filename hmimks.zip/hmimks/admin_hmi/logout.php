<?php
session_start();
session_unset();
session_destroy();

// Redirect ke halaman login atau halaman lain setelah logout
header("Location: ../login.php");
exit();
?>
