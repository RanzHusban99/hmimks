<?php
// Mulai sesi
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
include '../db.php';

// Proses jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $aktivitas = $_POST['aktivitas'];
    $tanggal = $_POST['tanggal'];
    $foto = $_FILES['foto']; // Menggunakan $_FILES untuk upload foto

    // Validasi file foto
    if ($foto['error'] == 0) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (in_array($foto['type'], $allowedTypes)) {
            // Tentukan direktori tujuan
            $uploadDir = 'foto_aktivitas/'; // Ganti dengan nama folder yang benar
            $uploadFile = $uploadDir . basename($foto['name']);

            // Pindahkan file ke direktori tujuan
            if (move_uploaded_file($foto['tmp_name'], $uploadFile)) {
                // Insert data laporan
                $query = "INSERT INTO laporan_aktivitas (aktivitas, tanggal, foto) VALUES ('$aktivitas', '$tanggal', '$uploadFile')";
                $conn->query($query);
                header("Location: laporan.php");
                exit();
            } else {
                echo "Terjadi kesalahan saat mengupload file.";
            }
        } else {
            echo "Tipe file tidak diizinkan.";
        }
    } else {
        echo "Terjadi kesalahan saat mengupload file.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <title>Tambah Laporan</title>
    <!-- Tambahkan CSS Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="icon" href="../storage/situs/HMI (Himpunan Mahasiswa Islam).png" type="image/png" /> <!-- Menambahkan logo situs -->
</head>
<body>
    <div class="container mt-4">
        <h1>Tambah Laporan</h1>
        <form method="POST" action="tambah_laporan.php" enctype="multipart/form-data"> <!-- Tambahkan enctype untuk upload file -->
            <div class="mb-3">
                <label class="form-label">Aktivitas:</label>
                <input type="text" name="aktivitas" class="form-control" required />
            </div>
            <div class="mb-3">
                <label class="form-label">Tanggal:</label>
                <input type="date" name="tanggal" class="form-control" required />
            </div>
            <div class="mb-3">
                <label class="form-label">Foto:</label>
                <input type="file" name="foto" class="form-control" /> <!-- Menggunakan input file untuk upload foto -->
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="laporan.php" class="btn btn-secondary">Kembali</a>
        </form>
        
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
