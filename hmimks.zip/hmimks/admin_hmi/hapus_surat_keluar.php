<?php
include '../db.php'; // Pastikan Anda menghubungkan file db.php dengan benar

$id = $_GET['id']; // Mengambil ID dari URL

// Query untuk menghapus data surat keluar berdasarkan ID
$query = "DELETE FROM surat_keluar WHERE id = $id";

if (mysqli_query($conn, $query)) {
    header("Location: surat_keluar.php");
    exit();
} else {
    echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
