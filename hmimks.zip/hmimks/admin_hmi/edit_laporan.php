<?php
// Mulai sesi
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
include '../db.php';

// Proses jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $aktivitas = $_POST['aktivitas'];
    $tanggal = $_POST['tanggal'];
    $foto = $_FILES['foto']; // Menggunakan $_FILES untuk upload foto

    // Logika untuk upload foto jika ada file yang diupload
    if ($foto['error'] == 0) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (in_array($foto['type'], $allowedTypes)) {
            $uploadDir = 'foto_aktivitas/'; // Pastikan folder ini ada
            $uploadFile = $uploadDir . basename($foto['name']);

            // Pindahkan file ke direktori tujuan
            if (move_uploaded_file($foto['tmp_name'], $uploadFile)) {
                // Update data laporan dengan foto baru
                $query = "UPDATE laporan_aktivitas SET aktivitas='$aktivitas', tanggal='$tanggal', foto='$uploadFile' WHERE id='$id'";
                $conn->query($query);
            } else {
                echo "Terjadi kesalahan saat mengupload file.";
            }
        } else {
            echo "Tipe file tidak diizinkan.";
        }
    } else {
        // Jika tidak ada file baru, tetap update tanpa mengubah foto
        $query = "UPDATE laporan_aktivitas SET aktivitas='$aktivitas', tanggal='$tanggal' WHERE id='$id'";
        $conn->query($query);
    }

    header("Location: laporan.php");
    exit();
}

// Ambil data laporan berdasarkan ID
$id = $_GET['id'];
$query = "SELECT * FROM laporan_aktivitas WHERE id='$id'";
$result = $conn->query($query);
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <title>Edit Laporan</title>
    <!-- Tambahkan CSS Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="icon" href="../storage/situs/HMI (Himpunan Mahasiswa Islam).png" type="image/png" /> <!-- Menambahkan logo situs -->
</head>
<body>
    <div class="container mt-4">
        <h1>Edit Laporan</h1>
        <form method="POST" action="edit_laporan.php" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>" />
            <div class="mb-3">
                <label class="form-label">Aktivitas:</label>
                <input type="text" name="aktivitas" value="<?php echo $row['aktivitas']; ?>" class="form-control" required />
            </div>
            <div class="mb-3">
                <label class="form-label">Tanggal:</label>
                <input type="date" name="tanggal" value="<?php echo $row['tanggal']; ?>" class="form-control" required />
            </div>
            <div class="mb-3">
                <label class="form-label">Foto:</label>
                <input type="file" name="foto" class="form-control" /> <!-- Menggunakan input file untuk upload foto -->
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="laporan.php" class="btn btn-secondary">Kembali</a>
        </form>
        
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
