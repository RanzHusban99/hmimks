<?php
// Sertakan file koneksi database
include '../db.php'; // pastikan file db.php berada di direktori yang sama

// Ambil nilai pencarian dari input
$search = isset($_POST['search']) ? $_POST['search'] : '';

// Query untuk mengambil data dengan pencarian
$sql = "SELECT * FROM `formulirsc` WHERE `nama` LIKE '%$search%'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Data Pendaftaran SC</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <link rel="icon" href="../storage/situs/HMI (Himpunan Mahasiswa Islam).png" type="image/png" /> <!-- Menambahkan logo situs -->
</head>
<body class="sb-nav-fixed">

<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Data Pendaftaran SC</h1>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    Data Pendaftaran
                </div>
                <div class="card-body">
                    <!-- Form Pencarian -->
                    <form method='POST' class='mb-4'>
                        <div class='input-group'>
                            <input type='text' name='search' class='form-control' placeholder='Cari nama...' value='<?php echo htmlspecialchars($search); ?>' style='width: 250px;'>
                            <button class='btn btn-primary' type='submit'>Cari</button>
                        </div>
                    </form>

                    <table id="datatablesSimple">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama</th>
                                <th>TTL</th>
                                <th>Asal Cabang</th>
                                <th>Email</th>
                                <th>No HP</th>
                                <th>Jabatan</th>
                                <th>Tahun LK1</th>
                                <th>Tahun LK2</th>
                                <th>Foto</th>   
                                <th>Sertifikat LK1</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    echo "<tr>
                                            <td>" . $row["id"] . "</td>
                                            <td>" . $row["nama"] . "</td>
                                            <td>" . $row["ttl"] . "</td>
                                            <td>" . $row["asal_cabang"] . "</td>
                                            <td>" . $row["email"] . "</td>
                                            <td>" . $row["no_hp"] . "</td>
                                            <td>" . $row["jabatan"] . "</td>
                                            <td>" . $row["tahun_lk1"] . "</td>
                                            <td>" . $row["tahun_lk2"] . "</td>
                                            <td><img src='../" . $row["foto"] . "' alt='Foto' width='100'></td>
                                            <td><img src='../" . $row["sertifikat_lk1"] . "' alt='Sertifikat LK1' width='100'></td>
                                          </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='10' class='text-center'>0 hasil</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
<script>
    window.addEventListener('DOMContentLoaded', event => {
        const datatablesSimple = document.getElementById('datatablesSimple');
        if (datatablesSimple) {
            new simpleDatatables.DataTable(datatablesSimple);
        }
    });
</script>

</body>
</html>

<?php
// Menutup koneksi
$conn->close();
?>
