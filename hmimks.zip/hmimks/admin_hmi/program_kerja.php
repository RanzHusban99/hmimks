<?php
include '../db.php'; // Menghubungkan ke database

// Fungsi untuk mengambil data program kerja
function getPrograms($search = '') {
    global $conn; // Menggunakan koneksi global
    $sql = "SELECT * FROM program_kerja WHERE name LIKE '%$search%'"; // Menambahkan pencarian
    return $conn->query($sql);
}

// Menangani aksi tambah, edit, hapus
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // ... kode untuk menangani aksi CRUD ...
    if (isset($_POST['edit'])) {
        $id = $_POST['edit'];
        header("Location: ubah_program_kerja.php?id=$id"); // Arahkan ke halaman edit
        exit();
    }
    if (isset($_POST['add'])) {
        header("Location: tambah_program_kerja.php"); // Arahkan ke halaman tambah
        exit();
    }
    if (isset($_POST['delete'])) {
        $id = $_POST['delete'];
        $sql = "DELETE FROM program_kerja WHERE id='$id'"; // Hapus dari database
        if ($conn->query($sql) === TRUE) {
            header("Location: program_kerja.php"); // Redirect setelah berhasil
            exit();
        } else {
            echo "Error: " . $conn->error;
        }
    }
    // ... kode untuk aksi lainnya ...
}

// Menampilkan data program kerja
$search = isset($_POST['search']) ? $_POST['search'] : '';
$programs = getPrograms($search);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Program Kerja</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <link rel="icon" href="../storage/situs/HMI (Himpunan Mahasiswa Islam).png" type="image/png" />
</head>
<body class="sb-nav-fixed">

<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Program Kerja</h1>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    Data Program Kerja
                </div>
                <div class="card-body">
                    
                    <!-- Tombol Tambah Data -->
                    <a href="tambah_program_kerja.php" class="btn btn-primary mb-4">Tambah Program Kerja</a>
                    <a href="index.php" class="btn btn-secondary mb-4">Beranda</a>
                    <table id="datatablesSimple">
                        <thead>
                            <tr>
                                <th>Nama Program Kerja</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $programs->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['name']; ?></td>
                                <td><?php echo $row['status']; ?></td>
                                <td>
                                    <form method="POST">
                                        <button type="submit" name="edit" value="<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Ubah</button>
                                        <button type="submit" name="delete" value="<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
<script>
    window.addEventListener('DOMContentLoaded', event => {
        const datatablesSimple = document.getElementById('datatablesSimple');
        if (datatablesSimple) {
            new simpleDatatables.DataTable(datatablesSimple);
        }
    });
</script>

</body>
</html>
