<?php
include '../db.php'; // Pastikan Anda menghubungkan file db.php dengan benar

$id = $_GET['id']; // Mengambil ID dari URL

// Query untuk menghapus data berdasarkan ID
$query = "DELETE FROM uang_masuk WHERE id = $id";

if (mysqli_query($conn, $query)) {
    header("Location: uang_masuk.php");
    exit();
} else {
    echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
