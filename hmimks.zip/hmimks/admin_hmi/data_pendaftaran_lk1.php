<?php
// Sertakan file koneksi database
include '../db.php'; // pastikan file db.php berada di direktori yang sama

// Ambil nilai pencarian dari input
$search = isset($_POST['search']) ? $_POST['search'] : '';

// Query untuk mengambil data dengan pencarian
$sql = "SELECT * FROM `formulirlk1` WHERE `nama` LIKE '%$search%'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Data Pendaftar LK1</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <link rel="icon" href="../storage/situs/HMI (Himpunan Mahasiswa Islam).png" type="image/png" /> <!-- Menambahkan logo situs -->
</head>
<body class="sb-nav-fixed">

<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Data Pendaftar LK1</h1>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    Data Pendaftar
                </div>
                <div class="card-body">
                    <a href="../index.html" class="btn btn-secondary mb-4">Beranda</a>
                   

                    <table id="datatablesSimple">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>TTL</th>
                                <th>Asal PT</th>
                                <th>Fakultas / Jurusan</th>
                                <th>Alamat</th>
                                <th>Nama Ayah / Ibu</th>
                                <th>No. HP / WA</th>
                                <th>Tujuan Masuk HMI</th>
                                <th>Foto</th>
                            </tr>
                        </thead>
                        <tbody>
    <?php
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            // Pastikan semua data ada dalam hasil query
            $nama = isset($row["nama"]) ? $row["nama"] : 'N/A';
            $email = isset($row["email"]) ? $row["email"] : 'N/A';
            $asal_pt = isset($row["asal_pt"]) ? $row["asal_pt"] : 'N/A';
            $ttl = isset($row["ttl"]) ? $row["ttl"] : 'N/A';
            $fakultas_jurusan = isset($row["fakultas_jurusan"]) ? $row["fakultas_jurusan"] : 'N/A';
            $alamat = isset($row["alamat"]) ? $row["alamat"] : 'N/A';
            $nama_ayah_ibu = isset($row["nama_ayah_ibu"]) ? $row["nama_ayah_ibu"] : 'N/A';
            $telp = isset($row["telp"]) ? $row["telp"] : 'N/A';
            $tujuan_masuk_hmi = isset($row["tujuan_masuk_hmi"]) ? $row["tujuan_masuk_hmi"] : 'N/A';


            echo "<tr>
                    <td>" . $row["id"] . "</td>
                    <td>" . $nama . "</td>
                    <td>" . $email . "</td>
                    <td>" . $ttl . "</td>
                    <td>" . $asal_pt . "</td>
                    <td>" . $fakultas_jurusan . "</td>
                    <td>" . $alamat . "</td>
                    <td>" . $nama_ayah_ibu . "</td>
                    <td>" . $telp . "</td>
                    <td>" . $tujuan_masuk_hmi . "</td>
                    <td><img src='../" . $row["foto"] . "' alt='Foto' width='100'></td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='10' class='text-center'>0 hasil</td></tr>";
    }
    ?>
</tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
<script>
    window.addEventListener('DOMContentLoaded', event => {
        const datatablesSimple = document.getElementById('datatablesSimple');
        if (datatablesSimple) {
            new simpleDatatables.DataTable(datatablesSimple);
        }
    });
</script>

</body>
</html>

<?php
// Menutup koneksi
$conn->close();
?>
