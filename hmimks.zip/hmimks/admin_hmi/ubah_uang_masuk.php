<?php
include '../db.php'; // Pastikan Anda menghubungkan file db.php dengan benar

$id = $_GET['id']; // Mengambil ID dari URL

// Query untuk mendapatkan data uang masuk berdasarkan ID
$query = "SELECT * FROM uang_masuk WHERE id = $id";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jumlah = $_POST['jumlah'];
    $tanggal = $_POST['tanggal'];
    $sumber = $_POST['sumber'];
    $keterangan = $_POST['keterangan'];

    // Query untuk mengupdate data
    $query = "UPDATE uang_masuk 
              SET jumlah='$jumlah', tanggal='$tanggal', sumber='$sumber', keterangan='$keterangan'
              WHERE id = $id";

    if (mysqli_query($conn, $query)) {
        header("Location: uang_masuk.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Uang Masuk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link rel="icon" href="../storage/situs/HMI (Himpunan Mahasiswa Islam).png" type="image/png" /> <!-- Menambahkan logo situs -->
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Ubah Uang Masuk</h2>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="jumlah" class="form-label">Jumlah</label>
                <input type="number" step="0.01" name="jumlah" class="form-control" value="<?php echo $data['jumlah']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal</label>
                <input type="date" name="tanggal" class="form-control" value="<?php echo $data['tanggal']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="sumber" class="form-label">Sumber</label>
                <input type="text" name="sumber" class="form-control" value="<?php echo $data['sumber']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="keterangan" class="form-label">Keterangan</label>
                <textarea name="keterangan" class="form-control" required><?php echo $data['keterangan']; ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Ubah</button>
            <a href="uang_masuk.php" class="btn btn-secondary">Kembali</a>
        </form>
        
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
