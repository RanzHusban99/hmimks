<?php
include '../db.php';

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    $sql = "DELETE FROM nama_kader WHERE id=$id";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Data berhasil dihapus.'); window.location.href='nama_kader.php';</script>";
    } else {
        echo "<script>alert('Error: " . $sql . " - " . mysqli_error($conn) . "'); window.location.href='nama_kader.php';</script>";
    }

    mysqli_close($conn);
} else {
    echo "<script>alert('ID tidak ditemukan.'); window.location.href='nama_kader.php';</script>";
}
