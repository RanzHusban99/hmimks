<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Nama Kader</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="../storage/situs/HMI (Himpunan Mahasiswa Islam).png" type="image/png" /> <!-- Menambahkan logo situs -->
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Tambah Nama Kader</h2>
    <form method="POST" action="" enctype="multipart/form-data"> <!-- Menambahkan enctype untuk upload file -->
        <div class="row mb-3">
            <div class="col-md-6">
                <label for="nama" class="form-label">Nama</label>
                <input type="text" class="form-control" id="nama" name="nama" required>
            </div>
            <div class="col-md-6">
                <label for="asal_pt" class="form-label">Asal PT</label>
                <input type="text" class="form-control" id="asal_pt" name="asal_pt" required>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-6">
                <label for="ttl" class="form-label">TTL</label>
                <input type="text" class="form-control" id="ttl" name="ttl" required>
            </div>
            <div class="col-md-6">
                <label for="fakultas_jurusan" class="form-label">Fakultas/Jurusan</label>
                <input type="text" class="form-control" id="fakultas_jurusan" name="fakultas_jurusan" required>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-6">
                <label for="alamat" class="form-label">Alamat</label>
                <input type="text" class="form-control" id="alamat" name="alamat" required>
            </div>
            <div class="col-md-6">
                <label for="nama_ayah_ibu" class="form-label">Nama Ayah/Ibu</label>
                <input type="text" class="form-control" id="nama_ayah_ibu" name="nama_ayah_ibu" required>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-6">
                <label for="telp" class="form-label">Telp</label>
                <input type="text" class="form-control" id="telp" name="telp" required>
            </div>
            <div class="col-md-6">
                <label for="tujuan_masuk_hmi" class="form-label">Tujuan Masuk HMI</label>
                <input type="text" class="form-control" id="tujuan_masuk_hmi" name="tujuan_masuk_hmi" required>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-6">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="col-md-6">
                <label for="foto" class="form-label">Foto</label>
                <input type="file" class="form-control" id="foto" name="foto"> <!-- Input untuk upload foto -->
            </div>
        </div>
        <div class="d-flex justify-content-end"> <!-- Mengubah justify-content menjadi end -->
                    <button type="submit" class="btn btn-warning me-2">Tambah</button> <!-- Menambahkan margin kanan -->
                    <a href="nama_kader.php" class="btn btn-secondary">Kembali</a>
                </div>
    </form>

    <?php
    include '../db.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nama = mysqli_real_escape_string($conn, $_POST['nama']);
        $asal_pt = mysqli_real_escape_string($conn, $_POST['asal_pt']);
        $ttl = mysqli_real_escape_string($conn, $_POST['ttl']);
        $fakultas_jurusan = mysqli_real_escape_string($conn, $_POST['fakultas_jurusan']);
        $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);
        $nama_ayah_ibu = mysqli_real_escape_string($conn, $_POST['nama_ayah_ibu']);
        $telp = mysqli_real_escape_string($conn, $_POST['telp']);
        $tujuan_masuk_hmi = mysqli_real_escape_string($conn, $_POST['tujuan_masuk_hmi']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);

        // Proses upload foto jika ada
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
            $target_dir = "admin_hmi/foto_kader/"; // Ganti dengan direktori penyimpanan yang sesuai
            $target_file = $target_dir . basename($_FILES["foto"]["name"]);

            // Pastikan direktori ada
            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0755, true); // Membuat direktori jika belum ada
            }

            move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file);
        }

        $sql = "INSERT INTO nama_kader (nama, asal_pt, ttl, fakultas_jurusan, alamat, nama_ayah_ibu, telp, tujuan_masuk_hmi, email, foto) VALUES ('$nama', '$asal_pt', '$ttl', '$fakultas_jurusan', '$alamat', '$nama_ayah_ibu', '$telp', '$tujuan_masuk_hmi', '$email', '$target_file')";

        if (mysqli_query($conn, $sql)) {
            // Redirect ke nama_kader.php setelah berhasil menambahkan data
            header("Location: nama_kader.php");
            exit(); // Pastikan untuk keluar setelah redirect
        } else {
            echo "<div class='alert alert-danger mt-3'>Error: " . $sql . "<br>" . mysqli_error($conn) . "</div>";
        }

        mysqli_close($conn);
    }
    ?>
</div>
</body>
</html>
