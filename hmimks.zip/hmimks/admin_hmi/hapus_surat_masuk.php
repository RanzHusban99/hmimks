<?php
include '../db.php'; // Pastikan Anda menghubungkan file db.php dengan benar

$id = $_GET['id']; // Mengambil ID dari URL

// Query untuk menghapus data
$query = "DELETE FROM surat_masuk WHERE id = $id";

if (mysqli_query($conn, $query)) {
    echo "Data berhasil dihapus.";
} else {
    echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);

// Redirect kembali ke halaman utama
header("Location: surat_masuk.php");
exit();
?>
