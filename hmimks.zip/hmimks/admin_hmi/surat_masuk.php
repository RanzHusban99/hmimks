<?php
include '../db.php'; // Pastikan Anda menghubungkan file db.php dengan benar

// Mengambil data dari tabel surat_masuk
$result = mysqli_query($conn, "SELECT * FROM surat_masuk");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Daftar Surat Masuk</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <link rel="icon" href="../storage/situs/HMI (Himpunan Mahasiswa Islam).png" type="image/png" /> <!-- Menambahkan logo situs -->
</head>
<body class="sb-nav-fixed">

<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Daftar Surat Masuk</h1>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    Data Surat Masuk
                </div>
                <div class="card-body">
                    <!-- Tombol Tambah Data -->
                    <a href="tambah_surat_masuk.php" class="btn btn-primary mb-4">Tambah Data</a>
                    <a href="index.php" class="btn btn-secondary mb-4">Beranda</a>

                    <table id="datatablesSimple">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>No Surat</th>
                                <th>Jenis Surat</th>
                                <th>Tanggal</th>
                                <th>Pengirim</th>
                                <th>Penerima</th>
                                <th>Perihal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>{$row['id']}</td>";
                                echo "<td>{$row['no_surat']}</td>";
                                echo "<td>{$row['jenis_surat']}</td>";
                                echo "<td>{$row['tanggal']}</td>";
                                echo "<td>{$row['pengirim']}</td>";
                                echo "<td>{$row['penerima']}</td>";
                                echo "<td>{$row['perihal']}</td>";
                                echo "<td>
                                    <a href='ubah_surat_masuk.php?id={$row['id']}' class='btn btn-warning btn-sm'>Ubah</a>
                                    <a href='hapus_surat_masuk.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Apakah Anda yakin ingin menghapus data ini?\")'>Hapus</a>
                                </td>";
                                echo "</tr>";
                            }

                            mysqli_close($conn);
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
<script>
    window.addEventListener('DOMContentLoaded', event => {
        const datatablesSimple = document.getElementById('datatablesSimple');
        if (datatablesSimple) {
            new simpleDatatables.DataTable(datatablesSimple);
        }
    });
</script>

</body>
</html>
