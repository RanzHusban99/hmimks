<?php
// Mulai sesi
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
include '../db.php';

// Ambil data laporan aktivitas
$query = "SELECT * FROM laporan_aktivitas ORDER BY tanggal DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Laporan Aktivitas - Admin HMI</title>
    <link href="css/styles.css" rel="stylesheet" />
    <!-- Ubah ke Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <link rel="icon" href="../storage/situs/HMI (Himpunan Mahasiswa Islam).png" type="image/png" /> <!-- Menambahkan logo situs -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#laporanTable').DataTable();
        });
    </script>
</head>
<body>
    
    <div class="container mt-4">
        <h1>Laporan Aktivitas</h1>
        <a href="tambah_laporan.php" class="btn btn-success mb-3">Tambah Laporan</a>
        <a href="index.php" class="btn btn-secondary mb-3">Beranda</a>
        <table id="laporanTable" class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Aktivitas</th>
                    <th>Tanggal</th>
                    <th>Foto</th>
                    <th>Aksi</th> <!-- Tambahkan kolom untuk aksi -->
                </tr>
            </thead>
            <tbody>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['aktivitas']; ?></td>
            <td><?php echo date('Y-m-d', strtotime($row['tanggal'])); ?></td> <!-- Mengubah format tanggal -->
            <td>
                <?php if ($row['foto']): ?>
                    <img src="<?php echo $row['foto']; ?>" alt="Foto Kegiatan" width="100" />
                <?php else: ?>
                    Tidak ada foto
                <?php endif; ?>
            </td>
            <td>
                <a href="edit_laporan.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                <a href="hapus_laporan.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus?');">Hapus</a>
            </td>
        </tr>
    <?php endwhile; ?>
</tbody>

            <tfoot>
                <tr>
                    
                </tr>
            </tfoot>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#laporanTable').DataTable();
        });
    </script>
    <script>
        function generatePDF() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            let tableContent = '';

            // Ambil data dari tabel
            $('#laporanTable tbody tr').each(function() {
                const row = $(this);
                const rowData = [];
                row.find('td').each(function() {
                    rowData.push($(this).text());
                });
                tableContent += rowData.join(' ') + '\n'; // Gabungkan data baris
            });

            doc.text("Laporan Aktivitas", 10, 10);
            doc.text(tableContent, 10, 20);
            doc.save('laporan_aktivitas.pdf'); // Simpan sebagai file PDF
        }
    </script>
</body>
</html>
