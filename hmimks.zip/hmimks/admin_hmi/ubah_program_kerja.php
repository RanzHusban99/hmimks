<?php
include '../db.php'; // Menghubungkan ke database

// Mengambil data program kerja berdasarkan ID
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM program_kerja WHERE id = $id";
    $result = $conn->query($sql);
    $program = $result->fetch_assoc();
}

// Menangani aksi update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $status = $_POST['status'];
    $sql = "UPDATE program_kerja SET name='$name', status='$status' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        header("Location: program_kerja.php"); // Redirect setelah update
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Ubah Program Kerja</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <link rel="icon" href="../storage/situs/HMI (Himpunan Mahasiswa Islam).png" type="image/png" />
</head>
<body class="sb-nav-fixed">

<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Ubah Program Kerja</h1>
            <div class="card mb-4">
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama Program Kerja</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo $program['name']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <div>
                                <input type="radio" id="terlaksana" name="status" value="terlaksana" <?php echo ($program['status'] == 'terlaksana') ? 'checked' : ''; ?> required>
                                <label for="terlaksana">Terlaksana</label>
                                <input type="radio" id="belum_terlaksana" name="status" value="belum terlaksana" <?php echo ($program['status'] == 'belum terlaksana') ? 'checked' : ''; ?> required>
                                <label for="belum_terlaksana">Belum Terlaksana</label>
                            </div>
                        </div>
                        <button type="ubah_program_kerja" class="btn btn-primary">Simpan</button>
                        <a href="program_kerja.php" class="btn btn-secondary">Batal</a>
                    </form>
                </div>
            </div>
        </div>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
<script>
    window.addEventListener('DOMContentLoaded', event => {
        // Inisialisasi DataTable jika diperlukan
    });
</script>

</body>
</html>
