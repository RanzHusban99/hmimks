<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Daftar Nama Kader</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <link rel="icon" href="../storage/situs/HMI (Himpunan Mahasiswa Islam).png" type="image/png" /> <!-- Menambahkan logo situs -->
</head>
<body class="sb-nav-fixed">

<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Daftar Nama Kader</h1>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    Data Nama Kader
                </div>
                <div class="card-body">
                    <!-- Tombol Tambah Data -->
                    <a href="tambah_nama_kader.php" class="btn btn-primary mb-4">Tambah Data</a>
                    <a href="import_nama_kader.php" class="btn btn-primary mb-4" onclick="document.getElementById('fileInput').click(); return false;">Impor Data</a>
                    <input type="file" id="fileInput" style="display: none;" onchange="this.form.submit();" />
                    <a href="index.php" class="btn btn-secondary mb-4">Beranda</a>

                    <table id="datatablesSimple">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama</th>
                                <th>Asal PT</th>
                                <th>TTL</th>
                                <th>Fakultas/Jurusan</th>
                                <th>Alamat</th>
                                <th>Nama Ayah/Ibu</th>
                                <th>Telp</th>
                                <th>Tujuan Masuk HMI</th>
                                <th>Email</th>
                                <th>Foto</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            include '../db.php'; // Pastikan Anda menghubungkan file db.php dengan benar

                            // Mengambil data dari tabel nama_kader
                            $result = mysqli_query($conn, "SELECT * FROM nama_kader");

                            while ($row = mysqli_fetch_assoc($result)) {
                                // Menampilkan foto hanya jika ada
                                $fotoPath = !empty($row['foto']) ? '../' . $row['foto'] : '';
                                echo "<tr>
                                        
                                        <td>" . $row['id'] . "</td>
                                        <td>{$row['nama']}</td>
                                        <td>{$row['asal_pt']}</td>
                                        <td>{$row['ttl']}</td>
                                        <td>{$row['fakultas_jurusan']}</td>
                                        <td>{$row['alamat']}</td>
                                        <td>{$row['nama_ayah_ibu']}</td>
                                        <td>{$row['telp']}</td>
                                        <td>{$row['tujuan_masuk_hmi']}</td>
                                        <td>{$row['email']}</td>
                                        <td><img src='" . $row['foto'] . "' alt='Foto' style='height: 50px;' onerror='this.onerror=null; this.src=\"path/to/default-image.png\";' /></td> 
                                        <td>
                                            <a href='ubah_nama_kader.php?id={$row['id']}' class='btn btn-warning btn-sm'>Ubah</a>
                                            <a href='hapus_nama_kader.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Apakah Anda yakin ingin menghapus data ini?\")'>Hapus</a>
                                        </td>
                                      </tr>";
                            }

                            mysqli_close($conn);
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
<script>
    window.addEventListener('DOMContentLoaded', event => {
        const datatablesSimple = document.getElementById('datatablesSimple');
        if (datatablesSimple) {
            new simpleDatatables.DataTable(datatablesSimple);
        }
    });
</script>

</body>
</html>
