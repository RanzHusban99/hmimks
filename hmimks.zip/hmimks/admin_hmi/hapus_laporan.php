<?php
// Mulai sesi
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
include '../db.php';

// Proses penghapusan
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM laporan_aktivitas WHERE id='$id'";
    $conn->query($query);
}

// Redirect kembali ke laporan
header("Location: laporan.php");
exit();
?>
