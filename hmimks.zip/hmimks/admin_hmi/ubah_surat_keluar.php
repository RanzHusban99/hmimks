<?php
include '../db.php'; // Pastikan Anda menghubungkan file db.php dengan benar

$id = $_GET['id']; // Mengambil ID dari URL

// Query untuk mendapatkan data surat keluar berdasarkan ID
$query = "SELECT * FROM surat_keluar WHERE id = $id";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $no_surat = $_POST['no_surat'];
    $jenis_surat = $_POST['jenis_surat'];
    $tanggal = $_POST['tanggal'];
    $pengirim = $_POST['pengirim'];
    $penerima = $_POST['penerima'];
    $perihal = $_POST['perihal'];

    // Query untuk mengupdate data
    $query = "UPDATE surat_keluar 
              SET no_surat='$no_surat', jenis_surat='$jenis_surat', tanggal='$tanggal', pengirim='$pengirim', penerima='$penerima', perihal='$perihal'
              WHERE id = $id";

    if (mysqli_query($conn, $query)) {
        header("Location: surat_keluar.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Surat Keluar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="../storage/situs/HMI (Himpunan Mahasiswa Islam).png" type="image/png" /> <!-- Menambahkan logo situs -->
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Ubah Surat Keluar</h2>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="no_surat" class="form-label">No Surat</label>
                <input type="text" class="form-control" name="no_surat" value="<?php echo $data['no_surat']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="jenis_surat" class="form-label">Jenis Surat</label>
                <input type="text" class="form-control" name="jenis_surat" value="<?php echo $data['jenis_surat']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal</label>
                <input type="date" class="form-control" name="tanggal" value="<?php echo $data['tanggal']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="pengirim" class="form-label">Pengirim</label>
                <input type="text" class="form-control" name="pengirim" value="<?php echo $data['pengirim']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="penerima" class="form-label">Penerima</label>
                <input type="text" class="form-control" name="penerima" value="<?php echo $data['penerima']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="perihal" class="form-label">Perihal</label>
                <textarea class="form-control" name="perihal" required><?php echo $data['perihal']; ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Ubah</button>
            <a href="surat_keluar.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
