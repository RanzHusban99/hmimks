<?php
session_start();

// Termasuk file koneksi database
include 'db.php';

// Proses jika form login dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Escape input untuk menghindari SQL Injection
    $email = mysqli_real_escape_string($conn, $email);
    $password = mysqli_real_escape_string($conn, $password);

    // Cek keberadaan user berdasarkan email
    $query = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);

        // Verifikasi password (tanpa hash, langsung dibandingkan)
        if ($password === $user['password']) {
            // Jika berhasil login
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['username'] = $user['username'];
            
            // Cek jenis pengguna
            if ($user['role'] === 'admin') {
                // Redirect ke halaman admin
                header("Location: admin_hmi/index.php");
            } else {
                // Redirect ke halaman pengguna
                header("Location: admin_hmi/data_pendaftaran_lk1.php");
            }
            exit;
        } else {
            $error = "Password salah.";
        }
    } else {
        $error = "Email tidak ditemukan.";
    }
}
?>

<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" 
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="WgPf900OPaCL66Xn8gxdp5Wu0RS0iP1YHQhCcDkk">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>HMI Makassar - Login</title>
    <link rel="apple-touch-icon" sizes="57x57" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
    <link rel="apple-touch-icon" sizes="60x60" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
    <link rel="apple-touch-icon" sizes="72x72" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
    <link rel="apple-touch-icon" sizes="76x76" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
    <link rel="apple-touch-icon" sizes="114x114" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
    <link rel="apple-touch-icon" sizes="120x120" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
    <link rel="apple-touch-icon" sizes="144x144" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
    <link rel="apple-touch-icon" sizes="152x152" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
    <link rel="apple-touch-icon" sizes="180x180" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
    <link rel="icon" type="image/png" sizes="192x192" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
    <link rel="icon" type="image/png" sizes="32x32" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
    <link rel="icon" type="image/png" sizes="96x96" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
    <link rel="icon" type="image/png" sizes="16x16" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
    <link href="storage/situs/HMI (Himpunan Mahasiswa Islam).png" rel="shortcut icon"> 
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="http://fonts.gstatic.com/">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="apps/app-assets/vendors/css/vendors.min.css">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="apps/app-assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="apps/app-assets/css/bootstrap-extended.css">
    <link rel="stylesheet" type="text/css" href="apps/app-assets/css/colors.css">
    <link rel="stylesheet" type="text/css" href="apps/app-assets/css/components.css">
    <link rel="stylesheet" type="text/css" href="apps/app-assets/css/themes/dark-layout.css">
    <link rel="stylesheet" type="text/css" href="apps/app-assets/css/themes/bordered-layout.css">
    <link rel="stylesheet" type="text/css" href="apps/app-assets/css/themes/semi-dark-layout.css">

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="apps/app-assets/css/core/menu/menu-types/vertical-menu.css">
    <link rel="stylesheet" type="text/css" href="apps/app-assets/css/plugins/forms/form-validation.css">
    <link rel="stylesheet" type="text/css" href="apps/app-assets/css/pages/page-auth.css">
    <link rel="stylesheet" type="text/css" href="apps/sweetalert2/sweetalert2.min.css">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="apps/assets/css/style.css">
	<script>
		var BASE_URL = "index.html";
	</script>
</head>
<body class="vertical-layout vertical-menu-modern blank-page navbar-floating footer-static menu-collapsed" data-open="click" data-menu="vertical-menu-modern" data-col="blank-page">
    <div id="app">
        <main class="py-4">
            <div class="app-content content">
                <div class="content-overlay"></div>
                <div class="header-navbar-shadow"></div>
                <div class="content-wrapper">
                    <div class="content-header row"></div>
                    <div class="content-body">
                        <div class="auth-wrapper auth-v1 px-2">
                            <div class="auth-inner py-2">
                                <!-- Login v1 -->
                                <div class="card mb-0">
                                    <div class="card-body">
                                        <a href="login.html" class="brand-logo">
                                            <h2 class="brand-text text-primary ml-1">LOGIN</h2>
                                        </a>
                                        <h4 class="card-title mb-1">Silahkan login</h4>
                                        <?php if (isset($error)): ?>
                                            <div class="alert alert-danger"><?php echo $error; ?></div>
                                        <?php endif; ?>
                                        <form id="form-data" class="auth-login-form mt-2" method="POST" action="">
                                            <div class="form-group">
                                                <label for="email" class="form-label">Email</label>
                                                <input type="text" class="form-control" id="email" name="email" required autocomplete="email" autofocus aria-describedby="login-email" tabindex="1" />
                                            </div>
                                            <div class="form-group">
                                                <div class="d-flex justify-content-between">
                                                    <label for="password">Password</label>
                                                </div>
                                                <div class="input-group input-group-merge form-password-toggle">
                                                    <input type="password" class="form-control form-control-merge" id="password" name="password" required autocomplete="current-password" tabindex="2" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;" aria-describedby="login-password" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text cursor-pointer"><i data-feather="eye"></i></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <button type="submit" class="btn btn-primary btn-block">
                                                Login
                                            </button>
                                            <a href="index.html" class="btn btn-secondary btn-block">
                                                Beranda
                                            </a>
                                            <br>
                                            <br>
                                            <center><small>HMI Makassar - All Rights Reserved</small></center>
                                            <br> 
                                        </form>
                                    </div>
                                </div>
                                <!-- /Login v1 -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- BEGIN: Vendor JS-->
    <script src="apps/app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="apps/app-assets/vendors/js/forms/validation/jquery.validate.min.js"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="apps/app-assets/js/core/app-menu.js"></script>
    <script src="apps/app-assets/js/core/app.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
	<script src="apps/assets/js/block.js"></script>
	<script src="apps/sweetalert2/sweetalert2.all.min.js"></script>
    <script src="apps/script/login.js"></script>
    <!-- END: Page JS-->

    <script>
        $(window).on('load', function() {
            if (feather) {
                feather.replace({
                    width: 14,
                    height: 14
                });
            }
        })
    </script>
</body>
</html>
