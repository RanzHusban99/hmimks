$(document).ready(function() {
    $('#login-form').on('submit', function(event) {
        event.preventDefault(); // Mencegah pengiriman formulir default

        var email = $('#email').val();
        var password = $('#password').val();

        $.ajax({
            url: 'login.php',
            method: 'POST',
            data: {
                email: email,
                password: password
            },
            success: function(response) {
                // Mengelola respons dari server
                if (response.trim() === "success") {
                    window.location.href = "admin_hmi/index.html";
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: response
                    });
                }
            },
            error: function(xhr, status, error) {
                console.error("Request failed: ", status, error);
            }
        });
    });
});
