// chatbot.js
document.getElementById('send-button').onclick = function() {
    var userInput = document.getElementById('user-input').value;
    if (userInput) {
        // Menampilkan pesan pengguna
        document.getElementById('chatbot-message').innerHTML = "Anda: " + userInput;

        // Balasan otomatis
        setTimeout(function() {
            var responses = {
                "Apa kabar?": "Saya baik-baik saja, terima kasih!",
                "Siapa namamu?": "Saya adalah chatbot.",
                "Terima kasih!": "Sama-sama!",
                "Apa itu HMI?": "HMI adalah Himpunan Mahasiswa Islam.",
                "Apa tujuan HMI?": "Tujuan HMI adalah untuk menciptakan kader yang berakhlak mulia.",
                "Di mana kantor HMI Makassar?": "Kantor HMI Makassar terletak di Jalan XYZ.",
                "Siapa ketua HMI saat ini?": "Ketua HMI saat ini adalah [Nama Ketua].",
                "Apa program kerja HMI?": "Program kerja HMI meliputi pendidikan, sosial, dan dakwah.",
                "Bagaimana cara bergabung dengan HMI?": "Anda bisa mendaftar melalui website resmi HMI.",
                "Apa saja kegiatan HMI?": "Kegiatan HMI meliputi seminar, pelatihan, dan pengabdian masyarakat.",
                "Apa visi HMI?": "Visi HMI adalah terwujudnya masyarakat yang adil dan makmur.",
                "Apa misi HMI?": "Misi HMI adalah menciptakan kader yang berintegritas.",
                "Siapa pendiri HMI?": "HMI didirikan oleh [Nama Pendiri].",
                "Apa saja organisasi yang berafiliasi dengan HMI?": "Beberapa organisasi yang berafiliasi adalah [Nama Organisasi].",
                "Apa peran HMI di masyarakat?": "HMI berperan dalam pengembangan masyarakat dan pendidikan.",
                "Bagaimana sejarah HMI?": "HMI didirikan pada tahun 1947.",
                "Apa saja cabang HMI di Indonesia?": "HMI memiliki cabang di berbagai universitas di Indonesia.",
                "Apa yang dimaksud dengan kader HMI?": "Kader HMI adalah anggota yang aktif dalam organisasi.",
                "Apa saja pelatihan yang disediakan HMI?": "HMI menyediakan pelatihan kepemimpinan dan manajemen.",
                "Apa itu Lembaga Pers Mahasiswa HMI?": "Lembaga Pers Mahasiswa HMI adalah media informasi HMI.",
                "Bagaimana cara mengikuti seminar HMI?": "Anda bisa mendaftar melalui website atau media sosial HMI.",
                "Apa saja prestasi HMI?": "HMI memiliki banyak prestasi di bidang sosial dan pendidikan.",
                "Apa itu HMI Komisariat?": "HMI Komisariat adalah unit organisasi di tingkat fakultas.",
                "Siapa saja alumni HMI yang terkenal?": "Beberapa alumni HMI yang terkenal adalah [Nama Alumni].",
                "Apa itu Musyawarah Nasional HMI?": "Musyawarah Nasional adalah forum tertinggi HMI.",
                "Apa saja isu yang diangkat HMI?": "HMI mengangkat isu-isu sosial, politik, dan pendidikan.",
                "Bagaimana cara menghubungi HMI Makassar?": "Anda bisa menghubungi melalui email atau media sosial.",
                "Apa itu HMI Cabang?": "HMI Cabang adalah organisasi HMI di tingkat kota.",
                "Apa saja kegiatan sosial HMI?": "Kegiatan sosial HMI meliputi bakti sosial dan pengabdian masyarakat.",
                "Apa itu HMI DPD?": "HMI DPD adalah Dewan Pimpinan Daerah HMI.",
                "Apa peran HMI dalam pendidikan?": "HMI berperan dalam meningkatkan kualitas pendidikan.",
                "Apa itu HMI Pusat?": "HMI Pusat adalah pengurus pusat HMI di Jakarta.",
                "Apa saja program unggulan HMI?": "Program unggulan HMI meliputi pendidikan dan pelatihan.",
                "Apa itu HMI dan perannya di kampus?": "HMI berperan dalam pengembangan mahasiswa di kampus.",
                "Apa saja kegiatan dakwah HMI?": "Kegiatan dakwah HMI meliputi pengajian dan seminar.",
                "Bagaimana cara menjadi pengurus HMI?": "Anda bisa mendaftar dan mengikuti seleksi pengurus.",
                "Apa itu HMI dan visi misinya?": "HMI memiliki visi untuk menciptakan masyarakat yang adil.",
                "Apa saja tantangan yang dihadapi HMI?": "Tantangan HMI meliputi isu sosial dan politik.",
                "Apa itu HMI dan sejarahnya?": "HMI didirikan untuk menciptakan kader yang berakhlak.",
                "Apa saja kegiatan HMI di luar kampus?": "Kegiatan HMI di luar kampus meliputi pengabdian masyarakat.",
                "Apa itu HMI dan tujuannya?": "Tujuan HMI adalah menciptakan kader yang berkualitas.",
                "Apa saja program kerja HMI Makassar?": "Program kerja HMI Makassar meliputi pendidikan dan sosial.",
                "Apa itu HMI dan perannya di masyarakat?": "HMI berperan dalam pengembangan masyarakat.",
                "Apa saja kegiatan HMI di bidang seni?": "Kegiatan seni HMI meliputi pertunjukan dan pameran.",
                "Apa itu HMI dan kontribusinya?": "HMI berkontribusi dalam pendidikan dan sosial.",
                "Apa saja kegiatan HMI di bidang olahraga?": "Kegiatan olahraga HMI meliputi turnamen dan lomba.",
                "Apa itu HMI dan dampaknya?": "HMI berdampak positif bagi mahasiswa dan masyarakat.",
                "Apa saja kegiatan HMI di bidang lingkungan?": "Kegiatan lingkungan HMI meliputi penghijauan dan kampanye.",
                "Apa itu HMI dan perannya dalam dakwah?": "HMI berperan dalam menyebarkan nilai-nilai Islam.",
                "Apa saja kegiatan HMI di bidang teknologi?": "Kegiatan teknologi HMI meliputi pelatihan dan seminar.",
                "Apa itu HMI dan kontribusinya terhadap bangsa?": "HMI berkontribusi dalam menciptakan pemimpin bangsa.",
                "Apa saja kegiatan HMI di bidang kesehatan?": "Kegiatan kesehatan HMI meliputi penyuluhan dan bakti sosial.",
                "Apa itu HMI dan perannya dalam politik?": "HMI berperan dalam menciptakan kader yang berintegritas.",
                "Apa saja kegiatan HMI di bidang ekonomi?": "Kegiatan ekonomi HMI meliputi pelatihan kewirausahaan.",
                "Apa itu HMI dan dampaknya bagi mahasiswa?": "HMI memberikan dampak positif bagi pengembangan diri mahasiswa."
            }; // Tambahkan pertanyaan dan jawaban di sini

            var response = responses[userInput] || "Maaf, saya tidak mengerti pertanyaan itu."; // Ganti dengan logika balasan yang diinginkan
            document.getElementById('chatbot-message').innerHTML = response;
        }, 1000); // Balasan muncul setelah 1 detik
    }
};