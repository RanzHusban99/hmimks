<?php
// Anda dapat menambahkan logika PHP di sini jika diperlukan
?>
<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" 
<head>
        <meta charset="utf-8">
        <meta name="csrf-token" content="WgPf900OPaCL66Xn8gxdp5Wu0RS0iP1YHQhCcDkk">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>HMI Makassar - Struktur Pengurus</title>
        <link rel="apple-touch-icon" sizes="57x57" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
        <link rel="apple-touch-icon" sizes="60x60" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
        <link rel="apple-touch-icon" sizes="72x72" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
        <link rel="apple-touch-icon" sizes="76x76" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
        <link rel="apple-touch-icon" sizes="114x114" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
        <link rel="apple-touch-icon" sizes="120x120" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
        <link rel="apple-touch-icon" sizes="144x144" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
        <link rel="apple-touch-icon" sizes="152x152" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
        <link rel="apple-touch-icon" sizes="180x180" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
        <link rel="icon" type="image/png" sizes="192x192" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
        <link rel="icon" type="image/png" sizes="32x32" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
        <link rel="icon" type="image/png" sizes="96x96" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
        <link rel="icon" type="image/png" sizes="16x16" href="storage/situs/HMI (Himpunan Mahasiswa Islam).png">
        <link href="storage/situs/HMI (Himpunan Mahasiswa Islam).png" rel="shortcut icon"> 
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> 
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&amp;family=Nunito:wght@600;700;800&amp;display=swap" rel="stylesheet">

        <link href="cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="cdn.jsdelivr.net/npm/bootstrap-icons%401.4.1/font/bootstrap-icons.css" rel="stylesheet">
        <!-- Styles -->
        <link rel="stylesheet" href="frontend/lib/animate/animate.min.css"> 
        <link rel="stylesheet" href="frontend/lib/owlcarousel/assets/owl.carousel.min.css"> 
        <link rel="stylesheet" href="frontend/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="frontend/css/style.css"> 
        <link rel="stylesheet" type="text/css" href="apps/sweetalert2/sweetalert2.min.css">
        
        <script>
          var BASE_URL = "index.html";
        </script>
      <style> 
        body {font-family: Nunito,sans-serif;}
        .text-title { font-family: Nunito,sans-serif!important; }
        .text-nunito { font-family: Nunito,sans-serif!important; }
        .items-event .owl-item img { height:200px !important; }
        .youtube-info iframe { width:100% !important; max-height:250px !important; }
        .page-header {
            background: linear-gradient(rgba(24, 29, 56, .7), rgba(24, 29, 56, .7)), url('..//hmimks/storage/banner/BG_utama2.png');
            background-position: center center;
            background-repeat: no-repeat;
            background-size: cover;
        }
      </style>     
    </head>
    <body id="berandaPage">
      <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
          <span class="sr-only">Loading...</span>
        </div>
      </div>
      <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <a href="index.html" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
          <h2 class="m-0 text-primary text-title">
          <img src="storage/situs/HMI (Himpunan Mahasiswa Islam).png" style="max-width:20px">
          HMI Makassar
          </h2>
        </a>
        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="index.html" class="nav-item nav-link ">Beranda</a>
            <div class="nav-item dropdown">
              <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Tentang</a>
              <div class="dropdown-menu fade-down m-0">
                <a href="index.html#tentangPage" class="dropdown-item">Tentang HMI</a> 
                <a href="tentang-hmi-makassar.html" class="dropdown-item ">Tentang HMI Makassar</a> 
              </div>
            </div>   
            <a href="index.html#visimisiPage" class="nav-item nav-link">Visi Misi</a> 
            <a href="pengurus.php" class="nav-item nav-link active">Struktur Pengurus</a> 
            <a href="index.html#cabangPage" class="nav-item nav-link">Komisariat</a>
            <div class="nav-item dropdown">
              <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Formulir</a>
              <div class="dropdown-menu fade-down m-0">
                <a href="formulir-lk1.html" class="dropdown-item">LK1</a> 
                <a href="formulir-lk2.html" class="dropdown-item">LK2</a> 
                <a href="formulir-sc.html" class="dropdown-item">SC</a> 
                <a href="index.html#pengaduanPage" class="dropdown-item">Pengaduan Kader</a> 
              </div>
            </div>  
             
            <a href="index.html#kontakPage" class="nav-item nav-link">Kontak</a> 
            <a href="login.php" class="nav-item nav-link" >Login</a>
          </div> 
        </div>
      </nav>  
	
    

    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;">
                <h6 class="section-title bg-white text-center text-primary px-3">HMI Makassar</h6>
                <h1 class="mb-5">Daftar Pengurus</h1>
            </div>
            <div class="row g-4">
                <!-- Daftar Pengurus -->
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid pengurus-step" src="storage/pengurus/logojpg.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="https://twitter.com/home"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Muh. Asmin</h5>
                            <small>Ketua Umum</small>
                        </div>
                    </div>
                </div> 
                <!-- Tambahkan pengurus lainnya di sini -->
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid pengurus-step" src="storage/pengurus/logojpg.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Muh. Husban</h5>
                            <small>Sekretaris Umum</small>
                        </div>
                    </div>
                </div> 
                                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid pengurus-step" src="storage/pengurus/logojpg.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">M. Gufroun Id Magfirah</h5>
                            <small>Bendahara Umum</small>
                        </div>
                    </div>
                </div> 
                                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid pengurus-step" src="storage/pengurus/logojpg.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Yusuf Kasim Bakri</h5>
                            <small>Ketua Bidang PAO</small>
                        </div>
                    </div>
                </div> 
                                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid pengurus-step" src="storage/pengurus/logojpg.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="https://www.instagram.com/atha_achmad/"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Muh. Faisal Ashabul Kahfi</h5>
                            <small>Staf PAO</small>
                        </div>
                    </div>
                </div> 
                                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid pengurus-step" src="storage/pengurus/logojpg.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Ishak B. Lakim</h5>
                            <small>Staf PAO</small>
                        </div>
                    </div>
                </div> 
                                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid pengurus-step" src="storage/pengurus/logojpg.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Isnaini Ahmad Renaldi</h5>
                            <small>Ketua Bidang PTKP</small>
                        </div>
                    </div>
                </div> 
                                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid pengurus-step" src="storage/pengurus/logojpg.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Muh. Zailani U. Pao</h5>
                            <small>Staf PTKP</small>
                        </div>
                    </div>
                </div> 
                                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid pengurus-step" src="storage/pengurus/logojpg.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Muhammad Kamal</h5>
                            <small>Staf PTKP</small>
                        </div>
                    </div>
                </div> 
                                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid pengurus-step" src="storage/pengurus/logojpg.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Yusran</h5>
                            <small>Ketua Bidang Rumah Tangga</small>
                        </div>
                    </div>
                </div> 
                                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid pengurus-step" src="storage/pengurus/logojpg.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Andi Zauqi</h5>
                            <small>Staf Rumah Tangga</small>
                        </div>
                    </div>
                </div> 
                                
                                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid pengurus-step" src="storage/pengurus/logojpg.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Dino Ode Kambisa</h5>
                            <small>Ketua KPC</small>
                        </div>
                    </div>
                </div> 
                                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid pengurus-step" src="storage/pengurus/logojpg.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" target="_blank" href="index.html"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Wardatullah Sultan</h5>
                            <small>Ketua Kohati</small>
                        </div>
                    </div>
                </div>
                <!-- ... -->
            </div>
        </div>
    </div>

    <div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s" id="kontakPage">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-4 col-md-12">
                    <h4 class="text-white mb-3">Link Terkait</h4>
                    <a class="btn btn-link" href="index.html#tentangPage">Tentang Kami</a>
                    <a class="btn btn-link" href="index.html#visimisiPage">Visi & Misi</a>
                    <a class="btn btn-link" href="pengurus.php">Struktur Pengurus</a> 
                    <a class="btn btn-link" href="index.html#cabangPage">Komisariat</a>
                </div>
                <div class="col-lg-4 col-md-12">
                    <h4 class="text-white mb-3">Kontak</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Jl. Tidung 6, Setapak 11, Kec. Tamalate, Kota Makassar, Sulawesi Selatan</p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>081341111373</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>hmimakassar@gmail.com</p>
                    <div class="d-flex pt-2">
                        <a class="btn btn-outline-light btn-social" target="_blank" href="https://twitter.com/hmimksr"><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-outline-light btn-social" target="_blank" href="https://web.facebook.com/www.hmimakassar.org"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-outline-light btn-social" target="_blank" href="https://www.instagram.com/hmi.mpo.makassar/"><i class="fab fa-instagram"></i></a>
                    </div>
                </div> 
                <div class="col-lg-4 col-md-12">
                    <h4 class="text-white mb-3">Berlangganan</h4>
                    <p>Daftar email Anda untuk mendapatkan informasi tambahan melalui email tersebut.</p>
                    <div class="position-relative mx-auto" style="max-width: 400px;">
                        <form id="form-subscriber" action="subscribe.php" method="POST">
                        <input type="hidden" name="_token" value="WgPf900OPaCL66Xn8gxdp5Wu0RS0iP1YHQhCcDkk">  
                        <input class="form-control border-0 w-100 py-3 ps-4 pe-5" type="email" id="email_subscriber" name="email_subscriber" placeholder="Alamat email.." required>
                        <button type="submit" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">Subscribe</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="border-bottom" href="#">HMI Makassar - All Rights Reserved</a>, 
                        Developed By <a class="border-bottom" href="#">HMI Makassar</a>
                    </div>
                    <div class="col-md-6 text-center text-md-end">
                        <div class="footer-menu">
                            <a href="index.html">Beranda</a>   
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Sukses -->
    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="successModalLabel">Berhasil!</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Anda telah berhasil berlangganan!
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Sukses untuk Pengaduan -->
    <div class="modal fade" id="pengaduanSuccessModal" tabindex="-1" aria-labelledby="pengaduanSuccessModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="pengaduanSuccessModalLabel">Berhasil!</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Pengaduan Anda telah berhasil dikirim!
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function showSuccessModal() {
            $('#successModal').modal('show');
            return true; // Mengizinkan pengiriman form
        }
    </script>

    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
        
    <script src="frontend/js/jquery-3.4.1.min.js"></script>
    <script src="frontend/js/bootstrap.bundle.min.js"></script>
    <script src="frontend/lib/wow/wow.min.js"></script>
    <script src="frontend/lib/easing/easing.min.js"></script>
    <script src="frontend/lib/waypoints/waypoints.min.js"></script>
    <script src="frontend/lib/owlcarousel/owl.carousel.min.js"></script> 
    <!-- Template Javascript -->
    <script src="frontend/js/main.js"></script> 
    <script src="frontend/js/tentang.js"></script> 
    <script src="apps/assets/js/block.js"></script>
    <script src="apps/sweetalert2/sweetalert2.all.min.js"></script>
    <script> 
        var _berandaPage = function() {
            $('html, body').animate({
                scrollTop: $("#berandaPage").offset().top
            }, 1000); 
        }
        var _tentangPage = function() {
            $('html, body').animate({
                scrollTop: $("#tentangPage").offset().top
            }, 1000); 
        }
        var _visimisiPage = function() {
            $('html, body').animate({
                scrollTop: $("#visimisiPage").offset().top
            }, 1000); 
        }
        var _strukturPage = function() {
            $('html, body').animate({
                scrollTop: $("#strukturPage").offset().top
            }, 1000); 
        }
        var _cabangPage = function() {
            $('html, body').animate({
                scrollTop: $("#cabangPage").offset().top
            }, 1000); 
        }
        var _lk1Page = function() {
            $('html, body').animate({
                scrollTop: $("#lk1Page").offset().top
            }, 1000); 
        }
        var _lk2Page = function() {
            $('html, body').animate({
                scrollTop: $("#lk2Page").offset().top
            }, 1000); 
        }
        var _scPage = function() {
            $('html, body').animate({
                scrollTop: $("#scPage").offset().top
            }, 1000); 
        }
        var _pengaduanPage = function() {
            $('html, body').animate({
                scrollTop: $("#pengaduanPage").offset().top
            }, 1000); 
        }
        var _newsPage = function() {
            $('html, body').animate({
                scrollTop: $("#newsPage").offset().top
            }, 1000); 
        }
        var _kontakPage = function() {
            $('html, body').animate({
                scrollTop: $("#kontakPage").offset().top
            }, 1000); 
        }
    </script>
    <script>
        $(document).ready(function(){
            var temp2 = 0;
            $('.berita-step').each(function (index) {
                if($(this).outerHeight() > temp2) {
                    temp2 = $(this).outerHeight();
                }          
            });
            $('.berita-step').css('min-height',temp2);
        });
    </script>  
    <script>
        $(document).ready(function(){
            var temp2 = 0;
            $('.cabang-step').each(function (index) {
                if($(this).outerHeight() > temp2) {
                    temp2 = $(this).outerHeight();
                }          
            });
            $('.cabang-step').css('min-height',temp2);
        });
    </script>   

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>

    <script>
        $('#form-pengaduan').on('submit', function(e) {
            e.preventDefault(); // Mencegah pengiriman form default

            $.ajax({
                type: 'POST',
                url: 'submit_pengaduan.php',
                data: $(this).serialize(),
                success: function(response) {
                    console.log(response); // Tambahkan log untuk debugging
                    response = JSON.parse(response); // Pastikan response di-parse
                    $('#form-pengaduan')[0].reset(); // Mengosongkan semua input dalam formulir
                    $('#pengaduanSuccessModal').modal('show'); // Menampilkan modal sukses
                },
                error: function() {
                    swal("Error!", "Terjadi kesalahan saat mengirim pengaduan.", "error");
                }
            });
        });
    </script>
    <script>
        $('#form-subscriber').on('submit', function(e) {
            e.preventDefault(); // Mencegah pengiriman form default

            $.ajax({
                type: 'POST',
                url: $(this).attr('action'),
                data: $(this).serialize(),
                success: function(response) {
                    // Mengganti respons JSON dengan pop up sukses Bootstrap
                    $('#form-subscriber')[0].reset(); // Mengosongkan semua input dalam formulir
                    $('#successModal').modal('show'); // Menampilkan modal sukses
                },
                error: function() {
                    swal("Error!", "Terjadi kesalahan saat mengirim data.", "error");
                }
            });
        });
    </script>
</body>
</html>