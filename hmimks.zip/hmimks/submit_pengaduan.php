<?php
include 'db.php'; // Mengimpor koneksi database

// Mengambil data dari request
$nama = $_POST['nama'];
$email = $_POST['email'];
$komisariat = $_POST['komisariat']; // Pastikan ini sesuai dengan nama input di form
$telp = $_POST['telp'];
$pengaduan = $_POST['pengaduan'];

// Menyiapkan dan mengeksekusi query
$stmt = $conn->prepare("INSERT INTO pengaduan (nama, email, komisariat, telp, isi_pengaduan) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $nama, $email, $komisariat, $telp, $pengaduan);

if ($stmt->execute()) {
    echo json_encode(['message' => 'Pengaduan berhasil dikirim!']);
} else {
    echo json_encode(['message' => 'Terjadi kesalahan saat menyimpan pengaduan: ' . $stmt->error]); // Menambahkan detail kesalahan
}

$stmt->close();
$conn->close();
?>
