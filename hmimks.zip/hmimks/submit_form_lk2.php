<?php
include 'db.php'; // Mengimpor koneksi database

// Mengaktifkan pelaporan kesalahan
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Ambil data dari formulir
$nama = $_POST['nama'] ?? null;
$ttl = $_POST['ttl'] ?? null;
$asal_cabang = $_POST['asal_cabang'] ?? null;
$email = $_POST['email'] ?? null;
$no_hp = $_POST['no_hp'] ?? null;
$jabatan = $_POST['jabatan'] ?? null; 
$foto = $_FILES['foto'] ?? null; 
$tahun_lk1 = $_POST['tahun_lk1'] ?? null;
$sertifikat_lk1 = $_FILES['sertifikat_lk1'] ?? null; 

// Periksa apakah semua nilai tidak null (jika kolom tidak boleh null)
if (empty($nama) || empty($ttl) || empty($asal_cabang) || empty($email) || empty($no_hp) || empty($jabatan) || empty($tahun_lk1) || empty($foto['name']) || empty($sertifikat_lk1['name'])) {
    echo json_encode(['status' => false, 'message' => 'Semua field wajib diisi.']);
    exit();
}

// Menangani upload foto jika ada
if ($foto && $foto['error'] == UPLOAD_ERR_OK) {
    $target_dir = "admin_hmi/form_upload_lk2/"; // Pastikan folder ini ada
    $foto_path = $target_dir . basename($foto['name']);
    
    // Pindahkan file ke folder uploads
    if (!move_uploaded_file($foto['tmp_name'], $foto_path)) {
        echo json_encode(['status' => false, 'message' => 'Terjadi kesalahan saat mengupload foto.']);
        exit();
    }
} else {
    echo json_encode(['status' => false, 'message' => 'Foto tidak valid.']);
    exit();
}

// Menangani upload sertifikat jika ada
if ($sertifikat_lk1 && $sertifikat_lk1['error'] == UPLOAD_ERR_OK) {
    $target_dir = "admin_hmi/sertifikat_lk1/"; // Pastikan folder ini ada
    $sertifikat_path = $target_dir . basename($sertifikat_lk1['name']);
    
    // Pindahkan file ke folder uploads
    if (!move_uploaded_file($sertifikat_lk1['tmp_name'], $sertifikat_path)) {
        echo json_encode(['status' => false, 'message' => 'Terjadi kesalahan saat mengupload sertifikat.']);
        exit();
    }
} else {
    echo json_encode(['status' => false, 'message' => 'Sertifikat tidak valid.']);
    exit();
}

// Menyiapkan dan mengeksekusi query
$stmt = $conn->prepare("INSERT INTO formulirlk2 (nama, ttl, asal_cabang, email, no_hp, jabatan, foto, tahun_lk1, sertifikat_lk1) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssssss", $nama, $ttl, $asal_cabang, $email, $no_hp, $jabatan, $foto_path, $tahun_lk1, $sertifikat_path);

if ($stmt->execute()) {
    // Menampilkan pesan sukses dengan Bootstrap 5 dan popup
    echo '<script>alert("Berhasil mengirim formulir LK2!"); setTimeout(function(){ window.location.href = "formulir-lk2.html"; }, 100);</script>'; // Redirect setelah 100 detik
} else {
    // Menampilkan pesan kesalahan dengan Bootstrap 5
    echo '<div class="alert alert-danger" role="alert">Terjadi kesalahan saat menyimpan pendaftaran: ' . $stmt->error . '</div>';
}

$stmt->close();
$conn->close();
?>