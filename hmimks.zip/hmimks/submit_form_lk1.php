<?php
include 'db.php'; // Mengimpor koneksi database

// Mengaktifkan pelaporan kesalahan
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Ambil data dari formulir
$nama = $_POST['nama'];
$ttl = $_POST['ttl'];
$asal_pt = $_POST['asal_pt']; // Ganti 'asal' menjadi 'asal_pt'
$fakultas_jurusan = $_POST['fakultas_jurusan']; // Tambahkan fakultas_jurusan

$alamat = $_POST['alamat'] ?? ''; // Menambahkan default value
$nama_ayah_ibu = $_POST['nama_ayah_ibu']; // Tambahkan nama_ayah_ibu
$telp = $_POST['telp'];
$email = $_POST['email'];
$tujuan_masuk_hmi = $_POST['tujuan_masuk_hmi']; // Ambil data tujuan_masuk_hmi

// Menangani upload foto jika ada
$foto = null;
if (isset($_FILES['foto'])) {
    // Cek error upload
    if ($_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['status' => false, 'message' => 'Error saat upload: ' . $_FILES['foto']['error']]);
        exit();
    }

    $target_dir = "admin_hmi/form_upload_lk1/"; // Pastikan folder ini ada
    $foto = $target_dir . basename($_FILES['foto']['name']);
    
    // Pengecekan ukuran file (misalnya maksimal 2MB)
    if ($_FILES['foto']['size'] > 2 * 1024 * 1024) {
        echo json_encode(['status' => false, 'message' => 'Ukuran file terlalu besar.']);
        exit();
    }

    // Pengecekan format file
    $allowed_types = ['image/jpeg', 'image/png'];
    if (!in_array($_FILES['foto']['type'], $allowed_types)) {
        echo json_encode(['status' => false, 'message' => 'Format file tidak didukung.']);
        exit();
    }

    // Pindahkan file ke folder uploads
    if (!move_uploaded_file($_FILES['foto']['tmp_name'], $foto)) {
        echo json_encode(['status' => false, 'message' => 'Terjadi kesalahan saat mengupload foto.']);
        exit();
    }
} else {
    echo json_encode(['status' => false, 'message' => 'Tidak ada file yang diupload.']);
}

// Menyiapkan dan mengeksekusi query
$stmt = $conn->prepare("INSERT INTO formulirlk1 (nama, asal_pt, ttl, fakultas_jurusan, alamat, nama_ayah_ibu, telp, tujuan_masuk_hmi, email, foto) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"); // Update query
$stmt->bind_param("ssssssssss", $nama, $asal_pt, $ttl, $fakultas_jurusan, $alamat, $nama_ayah_ibu, $telp, $tujuan_masuk_hmi, $email, $foto); // Update bind_param

if ($stmt->execute()) {
    // Menampilkan pesan sukses dengan Bootstrap 5 dan popup
    echo '<script>alert("Berhasil mengirim formulir LK1!"); setTimeout(function(){ window.location.href = "formulir-lk1.html"; }, 100);</script>'; // Redirect setelah 100 detik
} else {
    // Menampilkan pesan kesalahan dengan Bootstrap 5
    echo '<div class="alert alert-danger" role="alert">Terjadi kesalahan saat menyimpan pendaftaran: ' . $stmt->error . '</div>';
}

$stmt->close();
$conn->close();
?>