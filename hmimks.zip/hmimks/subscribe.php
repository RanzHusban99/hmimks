<?php
// Koneksi ke database
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email_subscriber']);

    // Validasi email
    if (empty($email)) {
        echo json_encode(['status' => 'error', 'message' => 'Email tidak boleh kosong.']);
        exit;
    }

    // Menyiapkan dan mengeksekusi query
    $stmt = $conn->prepare("INSERT INTO subscribers (email) VALUES (?)"); // Menghapus koma di akhir
    $stmt->bind_param("s", $email); // Mengganti $nama dengan $email dan mengubah tipe menjadi "s"

    if ($stmt->execute()) {
        // Mengganti json_encode dengan pop up sukses Bootstrap
        echo '<div class="alert alert-success" role="alert">Subscriber berhasil dikirim!</div>';
    } else {
        echo json_encode(['message' => 'Terjadi kesalahan saat menyimpan Subscriber: ' . $stmt->error]); // Menambahkan detail kesalahan
    }

    $stmt->close();
    $conn->close();
} // Pastikan kurung kurawal ini ditutup
?>

