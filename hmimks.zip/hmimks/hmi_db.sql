-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 11, 2024 at 10:05 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hmi_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `formulirlk1`
--

CREATE TABLE `formulirlk1` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `asal_pt` varchar(255) NOT NULL,
  `ttl` varchar(255) NOT NULL,
  `fakultas_jurusan` varchar(255) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `nama_ayah_ibu` varchar(255) NOT NULL,
  `telp` varchar(20) NOT NULL,
  `tujuan_masuk_hmi` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `formulirlk2`
--

CREATE TABLE `formulirlk2` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `ttl` varchar(100) NOT NULL,
  `asal_cabang` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_hp` varchar(15) DEFAULT NULL,
  `jabatan` varchar(100) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `tahun_lk1` varchar(4) NOT NULL,
  `sertifikat_lk1` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `formulirsc`
--

CREATE TABLE `formulirsc` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `ttl` varchar(25) NOT NULL,
  `asal_cabang` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `tahun_lk1` year(4) NOT NULL,
  `tahun_lk2` year(4) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `sertifikat_lk1` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `laporan_aktivitas`
--

CREATE TABLE `laporan_aktivitas` (
  `id` int(11) NOT NULL,
  `aktivitas` varchar(255) NOT NULL,
  `tanggal` datetime NOT NULL DEFAULT current_timestamp(),
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nama_kader`
--

CREATE TABLE `nama_kader` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `asal_pt` varchar(255) NOT NULL,
  `ttl` varchar(255) NOT NULL,
  `fakultas_jurusan` varchar(255) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `nama_ayah_ibu` varchar(255) NOT NULL,
  `telp` varchar(20) NOT NULL,
  `tujuan_masuk_hmi` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nama_kader`
--

INSERT INTO `nama_kader` (`id`, `nama`, `asal_pt`, `ttl`, `fakultas_jurusan`, `alamat`, `nama_ayah_ibu`, `telp`, `tujuan_masuk_hmi`, `email`, `foto`, `created_at`) VALUES
(1, 'RAHMATIKA. R', 'POLTEKKES', '-', 'FISIOTERAPI', 'JL. PACCERAKANG', 'ABD. RAHMAN/DARMAWATY', '085241302727', 'MENYANYI/KESADARAN', '-', '-', '2024-09-11 19:58:05'),
(2, 'MUH. ASWAR', 'UIM', '-', 'PENJASKESREK', 'BULUKUMBA', 'RUSLI/NAFISA', '085337331510', 'SEPAK BOLA/DIAJAK KADER', '-', '-', '2024-09-11 19:58:05'),
(3, 'M RIKAZ APRILLAH', 'UNHAS', '-', 'SASTRA ARAB', 'AROEPALA KOMP. PHL', 'NASRUN/HABSAH', '089531117910', 'SEPAK BOLA/MENAMBAH ILMU RELASI', '-', '-', '2024-09-11 19:58:05'),
(4, 'MUHAMMAD PUTRA', 'LP3I', '-', 'BISNIS DIGITAL', 'TAKALAR', 'MUHAMMAD AMIN/NURBIAH', '083136040190', 'MEMBACA/BELAJAR', '-', '-', '2024-09-11 19:58:05'),
(5, 'AAN RIZKI FAHMI', 'UNM', '-', 'BK', 'ALAUDDIN 2', 'SUDARIAIN/JOHARNI', '085373740724', 'FUTSAL/BELAJAR', '-', '-', '2024-09-11 19:58:05'),
(6, 'SUHAIL JUARIS', 'UNISMUH', '-', 'INFORMATIKA', 'ALAUDDIN 2', 'JUARIS/SUHARTI', '083114849092', 'SEPAK BOLA/INGIN MENCARI TAHU APA ITU HMI', '-', '-', '2024-09-11 19:58:05'),
(7, 'AKBAR SAKIR', 'UNISMUH', '-', 'MANAJEMEN', 'CITRA GARDEN', 'SAKIR/SAIMAWATI', '082193201014', 'INGIN BERPROSES DI HMI', '-', '-', '2024-09-11 19:58:05'),
(8, 'NUR MUH RIDWANSYAH AL-HABSY', 'LP3I', '-', 'ADMINISTRASI BISNIS', 'JL. MANGGARUPI', 'HAMZA/ST AMINA', '083173034507', 'MEMBACA/INGIN BERPROSES', '-', '-', '2024-09-11 19:58:05'),
(9, 'KURNI SUCIA RAMADANI', 'UNHAS', '-', 'SASTRA INDONESIA', 'BULUKUMBA', 'H. HERMAN/HJ. NURAENI', '085930105837', 'NONTON TIKTOK/INGIN MEMPERLUAS ILMU', '-', '-', '2024-09-11 19:58:05'),
(10, 'HELMALIA PUTRI YUSRAN', 'UNHAS', '-', 'ILMU HUKUM', 'ALAUDDIN 2', 'YUSRAN/IRMA', '085340992553', 'KEINGINAN', '-', '-', '2024-09-11 19:58:05'),
(11, 'MUH. QOYYUM AL- SAHHAFIM', 'UINAM', '-', 'TEKNIK INFORMATIKA', 'TODDOPULI 3 STPK 4', 'ISMAH', '082290211497', 'MEMBACA/CARI PENGALAMAN', 'BASTRA TGL 13 - 15 OKT 2023 DI SEKRETARIAT HMI BADKO SULSELBAR', '-', '2024-09-11 19:58:05'),
(12, 'MUHAJIR', 'UINAM', '-', 'KIMIA', 'GOWA', 'AMIRUDDIN', '085343971505', 'HAUS AKAN PENGETAHUAN', '-', '-', '2024-09-11 19:58:05'),
(13, 'MUH. ASHABUL AYMAN', 'UINAM', '-', 'SAA', 'SELAYAR', 'JUNAID', '081248621054', 'MENCARI PENGALAMAN', '-', '-', '2024-09-11 19:58:05'),
(14, 'MUH. FATIHUL RIZLY', 'UINAM', '-', 'AFI', 'KOLAKA UTARA', 'AKHMAD', '085343735012', 'MEMBACA/KARENA MAU', '-', '-', '2024-09-11 19:58:05'),
(15, 'AHMAD ALGITARI', 'UINAM', '-', 'SAA', 'BIMA, NTB', 'IDHAM', '082144177402', 'BOLA', '-', '-', '2024-09-11 19:58:05'),
(16, 'MUH TAUFIK HIDAYAT', 'UINAM', '-', 'SAA', 'BULUKUMBA', 'YUNUS', '085616483845', 'BADMINTON', '-', '-', '2024-09-11 19:58:05'),
(17, 'MUH ERLAN', 'UINAM', '-', 'SAA', 'ENREKANG', 'ATTONG', '085293365004', 'FUTSAL', '-', '-', '2024-09-11 19:58:05'),
(18, 'FATHURRAHMAN', 'UINAM', '-', 'SAA', 'GORONTALO', 'HAINA', '082192001044', 'STREET PHOTOGRAPHER', '-', '-', '2024-09-11 19:58:05'),
(19, 'MUH JIBRIL ILAHI', 'UINAM', '-', 'KIMIA', 'GOWA', 'SURATMI', '082194689654', 'RENANG', '-', '-', '2024-09-11 19:58:05'),
(20, 'RACHEL NAULI PADAULENG', 'UINAM', '-', 'ILMU HUKUM', 'MAROS', 'ADNAN MUHLIS', '081241766799', 'DENGAR MUSIK', '-', '-', '2024-09-11 19:58:05'),
(21, 'NUR ISLAMI', 'UINAM', '-', 'AFI', 'ENREKANG', 'SURIYATI', '087862399536', 'MASAK/PENASARAN', '-', '-', '2024-09-11 19:58:05'),
(22, 'NUR AZISAH AZIS', 'UINAM', '-', 'IQT', 'MAROS', 'AZIS', '082191893462', 'MASAK/PENASARAN', '-', '-', '2024-09-11 19:58:05'),
(23, 'FIRMAN ADI GHUNA', 'UIM', '-', '-', ' TAMALANREA', 'MENGGAMBAR', '081286153637', '-', '-', '-', '2024-09-11 19:58:05'),
(24, 'HARDIANSYAH. S', 'UIM', '-', '-', 'BORONG RAYA', 'FUTSAL', '-', '-', '-', '-', '2024-09-11 19:58:05'),
(25, 'MAS\'UD ABIL QOSIM', 'UIM', '-', '-', 'PERINTIS KEMERDEKAAN 7', 'FUTSAL', '082215403675', '-', '-', '-', '2024-09-11 19:58:05'),
(26, 'AHMAD SYAHID', 'UIM', '-', '-', 'PERINTIS KEMERDEKAAN 7', 'FUTSAL', '085298073561', '-', '-', '-', '2024-09-11 19:58:05'),
(27, 'MUH. YUSRIL', 'UIM', '-', '-', 'PERINTIS KEMERDEKAAN 7', 'FUTSAL', '081931536922', '-', '-', '-', '2024-09-11 19:58:05'),
(28, 'SULFITRAN', 'POLTEK ATIM', '-', '-', 'BORONG', 'FUTSAL', '082272759458', '-', '-', '-', '2024-09-11 19:58:05'),
(29, 'TAUFIK', 'UIM', '-', '-', 'JL. BUNG NO.10', 'MAIN BOLA', '082251574536', '-', '-', '-', '2024-09-11 19:58:05'),
(30, 'MUH. AFDHAL KURNIAWAN', 'UIM', '-', '-', 'PERUM. GRIYA HARAPAN', 'FUTSAL', '087846421030', '-', '-', '-', '2024-09-11 19:58:05'),
(31, 'KHATMI RAMANG', 'UIM', '-', '-', 'ANTANG', 'FUTSAL', '-', '-', '-', '-', '2024-09-11 19:58:05'),
(32, 'MUH. ALFIAN A', 'UIM', '-', '-', 'ANTANG', 'MAIN GAME', '081256963324', '-', '-', '-', '2024-09-11 19:58:05'),
(33, 'MUHAMMAD IKRAM', 'UIM', '-', '-', 'JL. HJ. KALLA', 'FUTSAL', '082136412687', '-', '-', '-', '2024-09-11 19:58:05'),
(34, 'NURUL AISYAH', 'UIM', '-', '-', 'JL. ASRAMA HAJI', 'MENULIS', '-', '-', '-', '-', '2024-09-11 19:58:05'),
(35, 'ALYA RAHMA WATI', 'UIM', '-', '-', 'PERINTIS KEMERDEKAAN 4', 'MEMBACA', '-', '-', '-', '-', '2024-09-11 19:58:05'),
(36, 'MUSTIKA ANGGRAENI ANWAR', 'UIM', '-', '-', 'HARTACO JAYA', 'MEMBACA', '-', '-', '-', '-', '2024-09-11 19:58:05'),
(37, 'AJENG NURUL ALFIAH', 'UIM', '-', '-', 'JL. IR. SOETAMI', 'MEMBACA', '-', '-', '-', '-', '2024-09-11 19:58:05'),
(38, 'M. WILDANI MUHLAS', 'UIM', '-', '-', 'PERINTIS KEMERDEKAAN 7', 'FUTSAL', '-', '-', '-', '-', '2024-09-11 19:58:05'),
(39, 'MUH. ALFIANSYAH', 'UIM', '-', '-', 'PERUMNAS BUMI MAROS INDAH', 'FUTSAL', '089561204727', '-', '-', '-', '2024-09-11 19:58:05'),
(40, 'A. ALFATHANA', 'UIM', '-', '-', 'JL. PELITA', 'MEMBACA', '-', '-', '-', '-', '2024-09-11 19:58:05'),
(41, 'MUHAMMAD REZA', 'LP3I', '-', 'ADMINISTRASI PERKANTORAN', 'DAYA', 'YUS', '089639472855', 'BACA BUKU/BINGUNG', '-', '-', '2024-09-11 19:58:05'),
(42, 'RACHMAT AGUS', 'LP3I', '-', 'BISNIS DIGITAL', 'PALANGGA', 'AGUS', '081255246695', 'BULU TANGKIS/KARENA TERTARIK', '-', '-', '2024-09-11 19:58:05'),
(43, 'HAIDIR', 'STIE WIRA BAKTI', '-', 'MANAJEMEN', 'MAKASSAR', 'ZAM-ZAM', '088246252475', 'FUTSAL/INGIN MENAMBAH ILMU AGAMA', '-', '-', '2024-09-11 19:58:05'),
(44, 'SUCI INDAH SARI', 'LP3I', '-', 'AKUNTANSI', 'JL. URIP SUMOHARJO', 'SUPID DG. BANI', '085298976350', 'MENARI/INGIN MENAMBAH ILMU AGAMA', '-', '-', '2024-09-11 19:58:05'),
(45, 'NISMAWATI BUR', 'LP3I', '-', 'AKUNTANSI', 'SYEKH YUSUF', 'BURHANUDDIN', '081241489334', 'MAKAN/MENAMBAH ILMU', '-', '-', '2024-09-11 19:58:05'),
(46, 'MILA KARMILA', 'LP3I', '-', 'ADMINISTRASI BISNIS', '-', '-', '087714344731', '-', '-', '-', '2024-09-11 19:58:05'),
(47, 'M. TAKDIR', 'UNISMUH', '-', '-', 'GOWA', 'SEPAK BOLA', '085823678534', '-', '-', '-', '2024-09-11 19:58:05'),
(48, 'MUH. AMIN AMIR', 'ITB NOBEL', '-', '-', 'JL. LANTO DG. PASEWANG', '-', '089685776257', '-', '-', '-', '2024-09-11 19:58:05'),
(49, 'AAN ANUGRAH', 'UINAM', '-', '-', 'MANGGARUPI', '-', '082399586824', 'BETERNAK', '-', '-', '2024-09-11 19:58:05'),
(50, 'JAHRIADI', 'UMI', '-', '-', 'PAMPANG II', '-', '081230551396', 'FUTSAL', '-', '-', '2024-09-11 19:58:05'),
(51, 'IRHAM RAMADHAN', 'UINAM', '-', '-', 'GOWA', '-', '085345259450', 'BADMINTON', '-', '-', '2024-09-11 19:58:05'),
(52, 'MUHSIN ALFIAN', 'UMI', '-', '-', 'MACCINI RAYA', '-', '085696593840', 'SEPAK BOLA', '-', '-', '2024-09-11 19:58:05'),
(53, 'NAJWAN HANIF', 'UINAM', '-', '-', 'TODDOPULI', '-', '081238436813', 'SEPAK BOLA', '-', '-', '2024-09-11 19:58:05'),
(54, 'NASRUDDIN', 'ITB NOBEL', '-', '-', 'JL. SUKARIA/RECING', '-', '082241031908', 'FUTSAL', '-', '-', '2024-09-11 19:58:05'),
(55, 'MUH. ARNOLD', 'WIRA BHAKTI', '-', '-', 'TEUKU UMUR 8 NO. 6', '-', '089767283089', 'OLAHRAGA', '-', '-', '2024-09-11 19:58:05'),
(56, 'MUHAMMAD ARSYAD', 'UNM', '-', '-', 'JL. RECING SIURI JALA', '-', '082193207621', 'OLAHRAGA', '-', '-', '2024-09-11 19:58:05'),
(57, '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '2024-09-11 19:58:05'),
(58, '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '2024-09-11 19:58:05'),
(59, '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '2024-09-11 19:58:05'),
(60, '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '2024-09-11 19:58:05'),
(61, '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '2024-09-11 19:58:05'),
(62, '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '2024-09-11 19:58:05');

-- --------------------------------------------------------

--
-- Table structure for table `pengaduan`
--

CREATE TABLE `pengaduan` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `komisariat` varchar(100) NOT NULL,
  `telp` varchar(15) NOT NULL,
  `isi_pengaduan` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `program_kerja`
--

CREATE TABLE `program_kerja` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('Terlaksana','Belum Terlaksana') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `email`, `created_at`) VALUES
(1, 'ranzhusban@gmail.com', '2024-09-11 19:05:06');

-- --------------------------------------------------------

--
-- Table structure for table `surat_keluar`
--

CREATE TABLE `surat_keluar` (
  `id` int(11) NOT NULL,
  `no_surat` varchar(50) NOT NULL,
  `jenis_surat` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `pengirim` varchar(100) NOT NULL,
  `penerima` varchar(100) NOT NULL,
  `perihal` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `surat_masuk`
--

CREATE TABLE `surat_masuk` (
  `id` int(11) NOT NULL,
  `no_surat` varchar(50) NOT NULL,
  `jenis_surat` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `pengirim` varchar(100) NOT NULL,
  `penerima` varchar(100) NOT NULL,
  `perihal` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `uang_keluar`
--

CREATE TABLE `uang_keluar` (
  `id` int(11) NOT NULL,
  `jumlah` decimal(15,2) NOT NULL,
  `tanggal` date NOT NULL,
  `tujuan` varchar(100) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `uang_masuk`
--

CREATE TABLE `uang_masuk` (
  `id` int(11) NOT NULL,
  `jumlah` decimal(15,2) NOT NULL,
  `tanggal` date NOT NULL,
  `sumber` varchar(100) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`) VALUES
(1, 'Muh. Husban', 'ranzhusban@gmail.com', '123', 'admin'),
(2, 'Yusuf', 'yusuf@gmail.com', '123', 'user'),
(3, 'Asmin', 'asmin@gmail.com', '123', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `formulirlk1`
--
ALTER TABLE `formulirlk1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `formulirlk2`
--
ALTER TABLE `formulirlk2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `formulirsc`
--
ALTER TABLE `formulirsc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `laporan_aktivitas`
--
ALTER TABLE `laporan_aktivitas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nama_kader`
--
ALTER TABLE `nama_kader`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengaduan`
--
ALTER TABLE `pengaduan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `program_kerja`
--
ALTER TABLE `program_kerja`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `surat_keluar`
--
ALTER TABLE `surat_keluar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surat_masuk`
--
ALTER TABLE `surat_masuk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uang_keluar`
--
ALTER TABLE `uang_keluar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uang_masuk`
--
ALTER TABLE `uang_masuk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `formulirlk1`
--
ALTER TABLE `formulirlk1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `formulirlk2`
--
ALTER TABLE `formulirlk2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `formulirsc`
--
ALTER TABLE `formulirsc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `laporan_aktivitas`
--
ALTER TABLE `laporan_aktivitas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nama_kader`
--
ALTER TABLE `nama_kader`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `pengaduan`
--
ALTER TABLE `pengaduan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `program_kerja`
--
ALTER TABLE `program_kerja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `surat_keluar`
--
ALTER TABLE `surat_keluar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `surat_masuk`
--
ALTER TABLE `surat_masuk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `uang_keluar`
--
ALTER TABLE `uang_keluar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `uang_masuk`
--
ALTER TABLE `uang_masuk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
